// Product Categories
export const categories = [
  {
    id: 1,
    name: 'Fruits',
    imageUrl: 'https://images.pexels.com/photos/1132047/pexels-photo-1132047.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 2,
    name: 'Vegetables',
    imageUrl: 'https://images.pexels.com/photos/2329440/pexels-photo-2329440.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 3,
    name: 'Cereals',
    imageUrl: 'https://images.pexels.com/photos/4813/wheat-field-cereals-grain.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 4,
    name: 'Pulses',
    imageUrl: 'https://images.pexels.com/photos/7656526/pexels-photo-7656526.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 5,
    name: 'Flour',
    imageUrl: 'https://images.pexels.com/photos/9086488/pexels-photo-9086488.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 6,
    name: 'Dairy Products',
    imageUrl: 'https://images.pexels.com/photos/248412/pexels-photo-248412.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  }
];

// Products
export const products = [
  // Fruits
  {
    id: 1,
    name: 'Organic Apples',
    price: 120,
    description: 'Fresh, juicy organic apples sourced from Himalayan orchards. Rich in antioxidants and fiber.',
    category: 'fruits',
    imageUrl: 'https://images.pexels.com/photos/1510392/pexels-photo-1510392.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 2,
    name: 'Alphonso Mangoes',
    price: 350,
    description: 'Premium Alphonso mangoes known for their rich flavor and smooth, fiberless pulp.',
    category: 'fruits',
    imageUrl: 'https://images.pexels.com/photos/918643/pexels-photo-918643.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 3,
    name: 'Bananas',
    price: 60,
    description: 'Perfectly ripened bananas packed with potassium and natural energy.',
    category: 'fruits',
    imageUrl: 'https://images.pexels.com/photos/1093038/pexels-photo-1093038.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 4,
    name: 'Strawberries',
    price: 180,
    description: 'Sweet and succulent strawberries, perfect for desserts or as a healthy snack.',
    category: 'fruits',
    imageUrl: 'https://images.pexels.com/photos/70746/strawberries-red-fruit-royalty-free-70746.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 5,
    name: 'Watermelon',
    price: 90,
    description: 'Refreshing watermelon with sweet, crisp flesh perfect for hot summer days.',
    category: 'fruits',
    imageUrl: 'https://images.pexels.com/photos/5946081/pexels-photo-5946081.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 6,
    name: 'Pomegranate',
    price: 140,
    description: 'Ruby red pomegranate filled with juicy arils rich in antioxidants.',
    category: 'fruits',
    imageUrl: 'https://images.pexels.com/photos/65256/pomegranate-open-cores-fruit-fruit-logistica-65256.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 7,
    name: 'Kiwi',
    price: 210,
    description: 'Tangy and sweet kiwi fruit packed with Vitamin C and dietary fiber.',
    category: 'fruits',
    imageUrl: 'https://images.pexels.com/photos/51312/kiwi-fruit-vitamins-healthy-eating-51312.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 8,
    name: 'Grapes',
    price: 160,
    description: 'Sweet and juicy grapes, perfect as a snack or for making juice.',
    category: 'fruits',
    imageUrl: 'https://images.pexels.com/photos/708777/pexels-photo-708777.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 9,
    name: 'Oranges',
    price: 80,
    description: 'Juicy, seedless oranges rich in Vitamin C and natural sweetness.',
    category: 'fruits',
    imageUrl: 'https://images.pexels.com/photos/42059/citrus-diet-food-fresh-42059.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  
  // Vegetables
  {
    id: 10,
    name: 'Fresh Spinach',
    price: 40,
    description: 'Nutrient-rich spinach leaves, perfect for salads and cooking.',
    category: 'vegetables',
    imageUrl: 'https://images.pexels.com/photos/2325843/pexels-photo-2325843.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 11,
    name: 'Tomatoes',
    price: 60,
    description: 'Ripe, juicy tomatoes perfect for salads, sauces, and cooking.',
    category: 'vegetables',
    imageUrl: 'https://images.pexels.com/photos/1327838/pexels-photo-1327838.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 12,
    name: 'Carrots',
    price: 45,
    description: 'Crunchy, sweet carrots rich in beta-carotene and fiber.',
    category: 'vegetables',
    imageUrl: 'https://images.pexels.com/photos/143133/pexels-photo-143133.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 13,
    name: 'Bell Peppers',
    price: 75,
    description: 'Colorful bell peppers with a sweet, crisp flavor.',
    category: 'vegetables',
    imageUrl: 'https://images.pexels.com/photos/1435904/pexels-photo-1435904.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 14,
    name: 'Cucumber',
    price: 35,
    description: 'Cool, refreshing cucumbers perfect for salads and sandwiches.',
    category: 'vegetables',
    imageUrl: 'https://images.pexels.com/photos/3568039/pexels-photo-3568039.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 15,
    name: 'Potatoes',
    price: 50,
    description: 'Versatile potatoes, perfect for boiling, baking, roasting, or frying.',
    category: 'vegetables',
    imageUrl: 'https://images.pexels.com/photos/144248/potatoes-vegetables-erdfrucht-bio-144248.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 16,
    name: 'Broccoli',
    price: 70,
    description: 'Nutritious broccoli florets, packed with vitamins and minerals.',
    category: 'vegetables',
    imageUrl: 'https://images.pexels.com/photos/47347/broccoli-vegetable-food-healthy-47347.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 17,
    name: 'Onions',
    price: 40,
    description: 'Essential onions for adding flavor to a wide variety of dishes.',
    category: 'vegetables',
    imageUrl: 'https://images.pexels.com/photos/144206/pexels-photo-144206.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 18,
    name: 'Cauliflower',
    price: 60,
    description: 'Fresh cauliflower, versatile for various cooking methods.',
    category: 'vegetables',
    imageUrl: 'https://images.pexels.com/photos/6316515/pexels-photo-6316515.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  
  // Cereals
  {
    id: 19,
    name: 'Rolled Oats',
    price: 120,
    description: 'Wholesome rolled oats, perfect for a nutritious breakfast.',
    category: 'cereals',
    imageUrl: 'https://images.pexels.com/photos/216951/pexels-photo-216951.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 20,
    name: 'Brown Rice',
    price: 85,
    description: 'Nutritious brown rice rich in fiber and essential nutrients.',
    category: 'cereals',
    imageUrl: 'https://images.pexels.com/photos/4110251/pexels-photo-4110251.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 21,
    name: 'Quinoa',
    price: 190,
    description: 'Protein-rich quinoa, a complete grain with all essential amino acids.',
    category: 'cereals',
    imageUrl: 'https://images.pexels.com/photos/7511748/pexels-photo-7511748.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 22,
    name: 'Millet',
    price: 75,
    description: 'Ancient grain millet, gluten-free and easily digestible.',
    category: 'cereals',
    imageUrl: 'https://images.pexels.com/photos/7728094/pexels-photo-7728094.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 23,
    name: 'Barley',
    price: 90,
    description: 'Hearty barley grain, perfect for soups and stews.',
    category: 'cereals',
    imageUrl: 'https://images.pexels.com/photos/1537169/pexels-photo-1537169.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 24,
    name: 'Corn Flakes',
    price: 150,
    description: 'Crispy corn flakes for a quick and easy breakfast.',
    category: 'cereals',
    imageUrl: 'https://images.pexels.com/photos/135525/pexels-photo-135525.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 25,
    name: 'Basmati Rice',
    price: 140,
    description: 'Aromatic basmati rice, perfect for biryanis and pulao.',
    category: 'cereals',
    imageUrl: 'https://images.pexels.com/photos/1565982/pexels-photo-1565982.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 26,
    name: 'Muesli',
    price: 210,
    description: 'Healthy muesli mix with nuts, seeds, and dried fruits.',
    category: 'cereals',
    imageUrl: 'https://images.pexels.com/photos/1374551/pexels-photo-1374551.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 27,
    name: 'Wheat Bran',
    price: 85,
    description: 'Fiber-rich wheat bran for adding nutrition to your diet.',
    category: 'cereals',
    imageUrl: 'https://images.pexels.com/photos/5765793/pexels-photo-5765793.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  
  // Pulses
  {
    id: 28,
    name: 'Moong Dal',
    price: 110,
    description: 'Split yellow moong dal, a light and easily digestible lentil.',
    category: 'pulses',
    imageUrl: 'https://images.pexels.com/photos/4198363/pexels-photo-4198363.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 29,
    name: 'Chana Dal',
    price: 95,
    description: 'Split chickpeas with mild, nutty flavor for hearty dishes.',
    category: 'pulses',
    imageUrl: 'https://images.pexels.com/photos/7421212/pexels-photo-7421212.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 30,
    name: 'Toor Dal',
    price: 120,
    description: 'Split pigeon peas, a staple for making sambar and dal.',
    category: 'pulses',
    imageUrl: 'https://images.pexels.com/photos/8014128/pexels-photo-8014128.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 31,
    name: 'Masoor Dal',
    price: 105,
    description: 'Red lentils that cook quickly and have a pleasant, earthy flavor.',
    category: 'pulses',
    imageUrl: 'https://images.pexels.com/photos/7439123/pexels-photo-7439123.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 32,
    name: 'Black Beans',
    price: 130,
    description: 'Protein-rich black beans for soups, stews, and salads.',
    category: 'pulses',
    imageUrl: 'https://images.pexels.com/photos/4110250/pexels-photo-4110250.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 33,
    name: 'Kidney Beans',
    price: 115,
    description: 'Red kidney beans, perfect for rajma and other bean dishes.',
    category: 'pulses',
    imageUrl: 'https://images.pexels.com/photos/5765788/pexels-photo-5765788.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 34,
    name: 'Green Moong',
    price: 140,
    description: 'Whole green gram for sprouting and making nutritious dishes.',
    category: 'pulses',
    imageUrl: 'https://images.pexels.com/photos/41961/pexels-photo-41961.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 35,
    name: 'Chickpeas',
    price: 100,
    description: 'Versatile chickpeas for hummus, curry, and salads.',
    category: 'pulses',
    imageUrl: 'https://images.pexels.com/photos/6316622/pexels-photo-6316622.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 36,
    name: 'Urad Dal',
    price: 125,
    description: 'Black gram split, essential for dosas, idlis, and dals.',
    category: 'pulses',
    imageUrl: 'https://images.pexels.com/photos/7591288/pexels-photo-7591288.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  
  // Flour
  {
    id: 37,
    name: 'Whole Wheat Flour',
    price: 60,
    description: 'Stone-ground whole wheat flour for healthier rotis and breads.',
    category: 'flour',
    imageUrl: 'https://images.pexels.com/photos/6605310/pexels-photo-6605310.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 38,
    name: 'All-Purpose Flour',
    price: 55,
    description: 'Versatile refined flour for baking and cooking.',
    category: 'flour',
    imageUrl: 'https://images.pexels.com/photos/5765784/pexels-photo-5765784.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 39,
    name: 'Besan (Gram Flour)',
    price: 85,
    description: 'Chickpea flour for making pakoras, sweets, and savory dishes.',
    category: 'flour',
    imageUrl: 'https://images.pexels.com/photos/4198402/pexels-photo-4198402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 40,
    name: 'Rice Flour',
    price: 75,
    description: 'Gluten-free rice flour for South Indian dishes and desserts.',
    category: 'flour',
    imageUrl: 'https://images.pexels.com/photos/6605643/pexels-photo-6605643.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 41,
    name: 'Ragi Flour',
    price: 90,
    description: 'Nutritious finger millet flour rich in calcium and iron.',
    category: 'flour',
    imageUrl: 'https://images.pexels.com/photos/5946082/pexels-photo-5946082.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 42,
    name: 'Corn Flour',
    price: 65,
    description: 'Fine corn flour for thickening gravies and baking.',
    category: 'flour',
    imageUrl: 'https://images.pexels.com/photos/5765793/pexels-photo-5765793.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 43,
    name: 'Jowar Flour',
    price: 80,
    description: 'Gluten-free sorghum flour for traditional breads and rotis.',
    category: 'flour',
    imageUrl: 'https://images.pexels.com/photos/7421212/pexels-photo-7421212.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 44,
    name: 'Almond Flour',
    price: 250,
    description: 'Low-carb almond flour for keto and gluten-free baking.',
    category: 'flour',
    imageUrl: 'https://images.pexels.com/photos/4198363/pexels-photo-4198363.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 45,
    name: 'Oat Flour',
    price: 120,
    description: 'Finely ground oat flour for healthy, fiber-rich baking.',
    category: 'flour',
    imageUrl: 'https://images.pexels.com/photos/7511741/pexels-photo-7511741.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  
  // Dairy Products
  {
    id: 46,
    name: 'Fresh Milk',
    price: 60,
    description: 'Farm-fresh milk, pasteurized for safety and taste.',
    category: 'dairy',
    imageUrl: 'https://images.pexels.com/photos/5946098/pexels-photo-5946098.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 47,
    name: 'Paneer',
    price: 90,
    description: 'Fresh, homemade cottage cheese for curries and snacks.',
    category: 'dairy',
    imageUrl: 'https://images.pexels.com/photos/4198102/pexels-photo-4198102.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 48,
    name: 'Curd',
    price: 40,
    description: 'Creamy, probiotic-rich yogurt for a healthy diet.',
    category: 'dairy',
    imageUrl: 'https://images.pexels.com/photos/6601341/pexels-photo-6601341.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 49,
    name: 'Butter',
    price: 120,
    description: 'Creamy, cultured butter made from pure milk cream.',
    category: 'dairy',
    imageUrl: 'https://images.pexels.com/photos/236776/pexels-photo-236776.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 50,
    name: 'Ghee',
    price: 450,
    description: 'Traditional clarified butter with a rich, nutty flavor.',
    category: 'dairy',
    imageUrl: 'https://images.pexels.com/photos/4198400/pexels-photo-4198400.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 51,
    name: 'Cheese',
    price: 180,
    description: 'Sliced cheese perfect for sandwiches and snacks.',
    category: 'dairy',
    imageUrl: 'https://images.pexels.com/photos/821365/pexels-photo-821365.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 52,
    name: 'Cream',
    price: 110,
    description: 'Fresh cream for desserts, coffee, and cooking.',
    category: 'dairy',
    imageUrl: 'https://images.pexels.com/photos/8471703/pexels-photo-8471703.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 53,
    name: 'Buttermilk',
    price: 30,
    description: 'Refreshing buttermilk, perfect for summer hydration.',
    category: 'dairy',
    imageUrl: 'https://images.pexels.com/photos/8471822/pexels-photo-8471822.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 54,
    name: 'Flavored Yogurt',
    price: 75,
    description: 'Delicious fruit-flavored yogurt for a healthy snack.',
    category: 'dairy',
    imageUrl: 'https://images.pexels.com/photos/4397754/pexels-photo-4397754.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  }
];