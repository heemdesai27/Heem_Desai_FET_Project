import { Truck, Shield, Award, Users } from 'lucide-react';

const About = () => {
  return (
    <div className="bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">About FreshBasket</h1>
          
          <div className="bg-white rounded-lg shadow-md overflow-hidden mb-12">
            <img 
              src="https://images.pexels.com/photos/1414651/pexels-photo-1414651.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="Organic farming" 
              className="w-full h-80 object-cover object-center"
            />
            
            <div className="p-6">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4">Our Story</h2>
              <p className="text-gray-600 mb-4">
                FreshBasket was founded in 2018 with a simple mission: to make fresh, high-quality groceries accessible to everyone. 
                What started as a small initiative working with a handful of local farmers has now grown into a trusted online grocery 
                platform serving thousands of customers across the country.
              </p>
              <p className="text-gray-600 mb-4">
                Our journey began when our founder, Rajesh Kumar, noticed the gap between farmers producing quality goods and urban 
                consumers seeking fresh produce. By eliminating middlemen and creating direct farm-to-table connections, we've been 
                able to ensure farmers get fair prices while customers receive the freshest products possible.
              </p>
              <p className="text-gray-600">
                Today, FreshBasket partners with over 500 farmers across India, supporting sustainable agricultural practices and 
                rural livelihoods while delivering farm-fresh goodness to urban doorsteps.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md overflow-hidden mb-12">
            <div className="p-6">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4">Our Mission</h2>
              <p className="text-gray-600 mb-6">
                At FreshBasket, we're committed to revolutionizing how people access fresh food by:
              </p>
              
              <ul className="space-y-4 mb-6">
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center text-white font-bold mr-3 mt-1">✓</div>
                  <p className="text-gray-600">Supporting local farmers and sustainable agriculture</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center text-white font-bold mr-3 mt-1">✓</div>
                  <p className="text-gray-600">Delivering the freshest, highest-quality produce possible</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center text-white font-bold mr-3 mt-1">✓</div>
                  <p className="text-gray-600">Making healthy eating accessible and convenient for all</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center text-white font-bold mr-3 mt-1">✓</div>
                  <p className="text-gray-600">Reducing food waste through efficient supply chains</p>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center text-white font-bold mr-3 mt-1">✓</div>
                  <p className="text-gray-600">Promoting environmental sustainability in all our operations</p>
                </li>
              </ul>
              
              <blockquote className="italic text-gray-600 border-l-4 border-green-500 pl-4 py-2 mb-4">
                "Our vision is a world where everyone has access to fresh, nutritious food, and where farmers are valued and 
                fairly compensated for their essential work."
                <footer className="text-right font-medium mt-2">- Rajesh Kumar, Founder</footer>
              </blockquote>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="flex justify-center mb-4">
                <Truck className="h-12 w-12 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Fast Delivery</h3>
              <p className="text-gray-600">We deliver your groceries within hours of harvesting</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="flex justify-center mb-4">
                <Shield className="h-12 w-12 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Quality Guarantee</h3>
              <p className="text-gray-600">100% satisfaction or your money back</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="flex justify-center mb-4">
                <Award className="h-12 w-12 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Certified Organic</h3>
              <p className="text-gray-600">All our produce meets strict organic standards</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="flex justify-center mb-4">
                <Users className="h-12 w-12 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Community Support</h3>
              <p className="text-gray-600">Supporting local farmers and communities</p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4">Join Our Mission</h2>
              <p className="text-gray-600 mb-6">
                Whether you're a customer, farmer, or potential team member, we invite you to join us in our mission to 
                transform how India eats. Together, we can build a healthier, more sustainable food system for all.
              </p>
              
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <button className="px-6 py-3 bg-green-600 text-white font-medium rounded-md hover:bg-green-700 transition-colors duration-200">
                  Shop Now
                </button>
                <button className="px-6 py-3 bg-white border border-green-600 text-green-600 font-medium rounded-md hover:bg-green-50 transition-colors duration-200">
                  Partner With Us
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;