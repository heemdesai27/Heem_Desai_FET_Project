import { Link } from 'react-router-dom';
import Hero from '../components/Hero';
import CategoryCard from '../components/CategoryCard';
import { categories } from '../data/data';

const Home = () => {
  return (
    <div>
      <Hero />
      
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Our Categories</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Explore our wide range of high-quality, farm-fresh groceries sorted into convenient categories.
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {categories.map((category) => (
              <CategoryCard 
                key={category.id}
                name={category.name}
                imageUrl={category.imageUrl}
              />
            ))}
          </div>
        </div>
      </section>
      
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="md:w-1/2 mb-8 md:mb-0 md:pr-8">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">Why Choose FreshBasket?</h2>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center text-white font-bold mr-3 mt-1">✓</div>
                  <div>
                    <h3 className="font-medium text-gray-800">Farm Fresh Produce</h3>
                    <p className="text-gray-600">Sourced directly from local farmers for maximum freshness.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center text-white font-bold mr-3 mt-1">✓</div>
                  <div>
                    <h3 className="font-medium text-gray-800">Fast Delivery</h3>
                    <p className="text-gray-600">Get your groceries delivered to your doorstep within hours.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center text-white font-bold mr-3 mt-1">✓</div>
                  <div>
                    <h3 className="font-medium text-gray-800">Quality Guarantee</h3>
                    <p className="text-gray-600">Not satisfied? Get a full refund or replacement.</p>
                  </div>
                </li>
              </ul>
              <Link 
                to="/products" 
                className="inline-block mt-6 px-6 py-3 bg-green-600 text-white font-medium rounded-md hover:bg-green-700 transition-colors duration-200"
              >
                Start Shopping
              </Link>
            </div>
            <div className="md:w-1/2">
              <img 
                src="https://images.pexels.com/photos/8108063/pexels-photo-8108063.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Fresh products" 
                className="rounded-lg shadow-md w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-16 bg-green-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Subscribe for Special Offers</h2>
          <p className="max-w-2xl mx-auto mb-8">
            Be the first to know about our special offers, new arrivals, and seasonal discounts.
          </p>
          <div className="max-w-md mx-auto flex flex-col sm:flex-row">
            <input 
              type="email" 
              placeholder="Your email address" 
              className="flex-grow px-4 py-3 mb-3 sm:mb-0 sm:mr-2 text-gray-800 rounded-md focus:outline-none"
            />
            <button className="bg-white text-green-600 px-6 py-3 rounded-md font-medium hover:bg-gray-100 transition-colors duration-200">
              Subscribe
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;