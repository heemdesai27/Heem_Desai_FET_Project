import { useState } from 'react';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import ContactForm from '../components/ContactForm';

const Contact = () => {
  const [activeTab, setActiveTab] = useState<'feedback' | 'support'>('feedback');

  return (
    <div className="bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">Contact Us</h1>
        
        <div className="max-w-5xl mx-auto">
          <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
            <div className="p-6">
              <div className="flex flex-wrap border-b mb-6">
                <button
                  className={`px-6 py-3 font-medium ${
                    activeTab === 'feedback'
                      ? 'text-green-600 border-b-2 border-green-600'
                      : 'text-gray-500 hover:text-gray-700'
                  } transition-colors duration-200`}
                  onClick={() => setActiveTab('feedback')}
                >
                  Feedback & Inquiries
                </button>
                <button
                  className={`px-6 py-3 font-medium ${
                    activeTab === 'support'
                      ? 'text-green-600 border-b-2 border-green-600'
                      : 'text-gray-500 hover:text-gray-700'
                  } transition-colors duration-200`}
                  onClick={() => setActiveTab('support')}
                >
                  Customer Support
                </button>
              </div>
              
              {activeTab === 'feedback' ? (
                <p className="text-gray-600 mb-6">
                  We'd love to hear from you! Whether you have suggestions, feedback, or business inquiries, 
                  please fill out the form below and our team will get back to you as soon as possible.
                </p>
              ) : (
                <p className="text-gray-600 mb-6">
                  Need help with your order or have questions about our products? Our customer support team 
                  is here to assist you. Fill out the form below or contact us directly using the information provided.
                </p>
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="md:col-span-2">
                  <ContactForm />
                </div>
                
                <div>
                  <div className="bg-gray-50 p-6 rounded-lg h-full">
                    <h2 className="text-xl font-semibold text-gray-800 mb-6">Get in Touch</h2>
                    
                    <div className="space-y-6">
                      <div className="flex items-start space-x-3">
                        <Phone className="h-5 w-5 text-green-600 mt-0.5" />
                        <div>
                          <p className="font-medium text-gray-800">Phone</p>
                          <p className="text-gray-600">+91 9876543210</p>
                          <p className="text-gray-600">+91 9876543211</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-3">
                        <Mail className="h-5 w-5 text-green-600 mt-0.5" />
                        <div>
                          <p className="font-medium text-gray-800">Email</p>
                          <p className="text-gray-600">support@freshbasket.com</p>
                          <p className="text-gray-600">info@freshbasket.com</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-3">
                        <MapPin className="h-5 w-5 text-green-600 mt-0.5" />
                        <div>
                          <p className="font-medium text-gray-800">Address</p>
                          <p className="text-gray-600">
                            123 Green Street, Fresh Market,<br />
                            Koramangala, Bangalore - 560034<br />
                            Karnataka, India
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-3">
                        <Clock className="h-5 w-5 text-green-600 mt-0.5" />
                        <div>
                          <p className="font-medium text-gray-800">Business Hours</p>
                          <p className="text-gray-600">Monday - Saturday: 8:00 AM - 8:00 PM</p>
                          <p className="text-gray-600">Sunday: 10:00 AM - 6:00 PM</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4">Our Location</h2>
              <div className="aspect-w-16 aspect-h-9 rounded-lg overflow-hidden">
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d248849.88651254103!2d77.49085722863283!3d12.954294595101903!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae1670c9b44e6d%3A0xf8dfc3e8517e4fe0!2sBengaluru%2C%20Karnataka!5e0!3m2!1sen!2sin!4v1619011794546!5m2!1sen!2sin" 
                  width="100%" 
                  height="450" 
                  style={{ border: 0 }} 
                  allowFullScreen={true} 
                  loading="lazy"
                  title="FreshBasket Location"
                  className="rounded-lg"
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;