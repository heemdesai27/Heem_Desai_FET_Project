import { useState } from 'react';
import ProductCard from '../components/ProductCard';
import { products } from '../data/data';

type Category = 'all' | 'fruits' | 'vegetables' | 'cereals' | 'pulses' | 'flour' | 'dairy';

const Products = () => {
  const [selectedCategory, setSelectedCategory] = useState<Category>('all');

  const categories: { id: Category; name: string }[] = [
    { id: 'all', name: 'All Products' },
    { id: 'fruits', name: 'Fruits' },
    { id: 'vegetables', name: 'Vegetables' },
    { id: 'cereals', name: 'Cereals' },
    { id: 'pulses', name: 'Pulses' },
    { id: 'flour', name: 'Flour' },
    { id: 'dairy', name: 'Dairy Products' }
  ];

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  const handleAddToCart = (product: typeof products[0]) => {
    // TODO: Implement cart functionality
    console.log('Adding to cart:', product);
  };

  return (
    <div className="bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-800 mb-8 text-center">Our Products</h1>
        
        <div className="flex flex-wrap justify-center mb-8">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`m-1 px-4 py-2 rounded-full ${
                selectedCategory === category.id
                  ? 'bg-green-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              } transition-colors duration-200`}
            >
              {category.name}
            </button>
          ))}
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard 
              key={product.id}
              {...product}
              onAddToCart={() => handleAddToCart(product)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Products;