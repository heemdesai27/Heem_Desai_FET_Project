const Hero = () => {
  return (
    <div className="relative bg-green-700 text-white">
      <div className="absolute inset-0">
        <img 
          src="https://images.pexels.com/photos/1660027/pexels-photo-1660027.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
          alt="Fresh vegetables and fruits" 
          className="w-full h-full object-cover opacity-40"
        />
      </div>
      <div className="relative container mx-auto px-4 py-20 sm:py-32">
        <div className="max-w-2xl">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            Farm Fresh Groceries Delivered to Your Doorstep
          </h1>
          <p className="text-lg sm:text-xl mb-8">
            Quality products sourced directly from farmers. Experience freshness like never before.
          </p>
          <div className="flex flex-wrap gap-4">
            <button className="px-6 py-3 bg-white text-green-700 font-medium rounded-md hover:bg-gray-100 transition-colors duration-200">
              Shop Now
            </button>
            <button className="px-6 py-3 bg-transparent border-2 border-white text-white font-medium rounded-md hover:bg-white hover:bg-opacity-10 transition-colors duration-200">
              Learn More
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;