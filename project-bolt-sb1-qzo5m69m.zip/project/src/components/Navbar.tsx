import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { ShoppingBag, Menu, X, ShoppingCart } from 'lucide-react';
import CartModal from './CartModal';

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
}

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const updateQuantity = (id: number, quantity: number) => {
    if (quantity === 0) {
      removeItem(id);
      return;
    }
    setCartItems(items =>
      items.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const removeItem = (id: number) => {
    setCartItems(items => items.filter(item => item.id !== id));
  };

  const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <NavLink to="/" className="flex items-center space-x-2">
            <ShoppingBag className="h-8 w-8 text-green-600" />
            <span className="text-xl font-bold text-gray-800">FreshBasket</span>
          </NavLink>

          {/* Desktop menu */}
          <div className="hidden md:flex items-center space-x-8">
            <NavLink 
              to="/" 
              className={({ isActive }) => 
                isActive ? "text-green-600 font-medium" : "text-gray-600 hover:text-green-600 transition-colors duration-200"
              }
            >
              Home
            </NavLink>
            <NavLink 
              to="/products" 
              className={({ isActive }) => 
                isActive ? "text-green-600 font-medium" : "text-gray-600 hover:text-green-600 transition-colors duration-200"
              }
            >
              Products
            </NavLink>
            <NavLink 
              to="/about" 
              className={({ isActive }) => 
                isActive ? "text-green-600 font-medium" : "text-gray-600 hover:text-green-600 transition-colors duration-200"
              }
            >
              About
            </NavLink>
            <NavLink 
              to="/contact" 
              className={({ isActive }) => 
                isActive ? "text-green-600 font-medium" : "text-gray-600 hover:text-green-600 transition-colors duration-200"
              }
            >
              Contact
            </NavLink>
            <button 
              onClick={() => setIsCartOpen(true)}
              className="relative text-gray-600 hover:text-green-600 transition-colors duration-200"
            >
              <ShoppingCart className="h-6 w-6" />
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-green-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center gap-4">
            <button 
              onClick={() => setIsCartOpen(true)}
              className="relative text-gray-600 hover:text-green-600 transition-colors duration-200"
            >
              <ShoppingCart className="h-6 w-6" />
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-green-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </button>
            <button onClick={toggleMenu} className="text-gray-600 focus:outline-none">
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 space-y-4">
            <NavLink 
              to="/" 
              className={({ isActive }) => 
                `block ${isActive ? "text-green-600 font-medium" : "text-gray-600 hover:text-green-600 transition-colors duration-200"}`
              }
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </NavLink>
            <NavLink 
              to="/products" 
              className={({ isActive }) => 
                `block ${isActive ? "text-green-600 font-medium" : "text-gray-600 hover:text-green-600 transition-colors duration-200"}`
              }
              onClick={() => setIsMenuOpen(false)}
            >
              Products
            </NavLink>
            <NavLink 
              to="/about" 
              className={({ isActive }) => 
                `block ${isActive ? "text-green-600 font-medium" : "text-gray-600 hover:text-green-600 transition-colors duration-200"}`
              }
              onClick={() => setIsMenuOpen(false)}
            >
              About
            </NavLink>
            <NavLink 
              to="/contact" 
              className={({ isActive }) => 
                `block ${isActive ? "text-green-600 font-medium" : "text-gray-600 hover:text-green-600 transition-colors duration-200"}`
              }
              onClick={() => setIsMenuOpen(false)}
            >
              Contact
            </NavLink>
          </div>
        )}
      </div>

      <CartModal
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={updateQuantity}
        onRemoveItem={removeItem}
      />
    </nav>
  );
};

export default Navbar;