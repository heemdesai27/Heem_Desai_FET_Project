import { NavLink } from 'react-router-dom';
import { ShoppingBag, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <ShoppingBag className="h-6 w-6 text-green-400" />
              <span className="text-lg font-bold">FreshBasket</span>
            </div>
            <p className="text-gray-300 text-sm">
              Your trusted online grocery store, bringing farm-fresh products directly to your doorstep.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <NavLink to="/" className="text-gray-300 hover:text-white transition-colors duration-200">
                  Home
                </NavLink>
              </li>
              <li>
                <NavLink to="/products" className="text-gray-300 hover:text-white transition-colors duration-200">
                  Products
                </NavLink>
              </li>
              <li>
                <NavLink to="/about" className="text-gray-300 hover:text-white transition-colors duration-200">
                  About Us
                </NavLink>
              </li>
              <li>
                <NavLink to="/contact" className="text-gray-300 hover:text-white transition-colors duration-200">
                  Contact
                </NavLink>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-4">Categories</h3>
            <ul className="space-y-2">
              <li>
                <NavLink to="/products" className="text-gray-300 hover:text-white transition-colors duration-200">
                  Fruits
                </NavLink>
              </li>
              <li>
                <NavLink to="/products" className="text-gray-300 hover:text-white transition-colors duration-200">
                  Vegetables
                </NavLink>
              </li>
              <li>
                <NavLink to="/products" className="text-gray-300 hover:text-white transition-colors duration-200">
                  Cereals
                </NavLink>
              </li>
              <li>
                <NavLink to="/products" className="text-gray-300 hover:text-white transition-colors duration-200">
                  Dairy Products
                </NavLink>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <Phone className="h-5 w-5 text-green-400 mt-0.5" />
                <span className="text-gray-300">+91 9876543210</span>
              </li>
              <li className="flex items-start space-x-3">
                <Mail className="h-5 w-5 text-green-400 mt-0.5" />
                <span className="text-gray-300">support@freshbasket.com</span>
              </li>
              <li className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-green-400 mt-0.5" />
                <span className="text-gray-300">123 Green Street, Fresh Market, Bangalore, India</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} FreshBasket. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;