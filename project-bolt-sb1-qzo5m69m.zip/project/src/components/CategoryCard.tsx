import { NavLink } from 'react-router-dom';

interface CategoryCardProps {
  name: string;
  imageUrl: string;
}

const CategoryCard = ({ name, imageUrl }: CategoryCardProps) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden group transition-transform duration-300 hover:-translate-y-1">
      <div className="h-48 overflow-hidden">
        <img 
          src={imageUrl} 
          alt={name} 
          className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <div className="px-4 py-4 text-center">
        <h3 className="text-lg font-medium text-gray-800 mb-3">{name}</h3>
        <NavLink 
          to="/products" 
          className="inline-block px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors duration-200"
        >
          Shop Now
        </NavLink>
      </div>
    </div>
  );
};

export default CategoryCard;