interface ProductProps {
  id: number;
  name: string;
  price: number;
  description: string;
  category: string;
  imageUrl: string;
  onAddToCart?: () => void;
}

const ProductCard = ({ name, price, description, imageUrl, onAddToCart }: ProductProps) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden flex flex-col h-full group">
      <div className="h-48 overflow-hidden">
        <img 
          src={imageUrl} 
          alt={name} 
          className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-medium text-gray-800">{name}</h3>
          <span className="font-medium text-green-600">₹{price}</span>
        </div>
        <p className="text-gray-600 text-sm flex-grow">{description}</p>
        <button 
          onClick={onAddToCart}
          className="mt-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors duration-200 w-full flex items-center justify-center gap-2"
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default ProductCard;